create view productmanagement as
select `s`.`id`          AS `id`,
       `d`.`tendanhmuc`  AS `tendanhmuc`,
       `s`.`tensanpham`  AS `tensanpham`,
       `s`.`anhbia`      AS `anhbia`,
       `s`.`gia`         AS `gia`,
       `s`.`trangthai`   AS `trangthai`,
       `s`.`createddate` AS `createddate`
from (`cozastore`.`sanpham` `s`
         left join `cozastore`.`danhmuc` `d` on (`s`.`madanhmuc` = `d`.`madanhmuc`));

